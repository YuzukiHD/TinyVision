﻿Sdd Editor ex version:2.7.210115a
- 新增高频晶振32M的下拉选项
- 修改Tx Power按钮：当识别sdd文件小于等于2.4版本时，显示的是Max/Min Power值；当识别sdd文件大于2.4版本时，显示的是User Power值

Sdd Editor ex version:2.7.201217a
- 更新版本号，解决新版SDD文件会报版本不匹配的问题
- 不再将工具版本号更新至sdd文件中

Sdd Editor ex version:2.6.200918a
- 更新版本号，解决新版SDD文件会报版本不匹配的问题

Sdd Editor ex version:2.5.191212a
- 增加正式版本，可供用户编辑晶振频率、频偏、发射功率
- 可以直接打开bin或者sdd后缀名的文件
- 支持文件拖拽功能


