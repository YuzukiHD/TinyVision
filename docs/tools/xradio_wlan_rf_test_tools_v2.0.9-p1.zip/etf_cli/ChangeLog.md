version: v2.0.9

- 支持xr819s读写efuse

version: v2.0.8

- 修复了信道设置异常的问题

version: v2.0.7

- 修复了XR819S功率偏低的问题

version: v2.0.6

- 添加默认sdd版本号以修复因读取不到sdd版本号而导致etf工具异常的问题
- 修正LOWER或UPPER定义，与802.11标准一致。

version: v2.0.4

- 通过读取固件版本识别xr819s，自适应选择参数
- 根据sdd版本处理功率-3dB操作
- 根据sdd版本设置选择user power或max power
- 支持cca设置
- 增加版本管理，版本不对应则有相应提示

version: v1.4.1

- 支持读写efuse的频偏值。

version: v1.3.7

- 支持频偏临时调整