# RFTester.apk

RFTester.apk是广州芯之联科技有限公司 (Xradio Technology) 用于检测其无线芯片RF性能的GUI测试工具

- 支持芯片：XR819、XR829、XR819S
- 使用说明：在AndroidQ或AndroidR平台下安装使用。详细使用规则请咨询相关FAE
- 版本说明：请查看[ChangeLog.md](./ChangeLog.md)，以下为各芯片驱动版本支持对应表

注：
1. 因Android系统特性，apk需要进行签名，如果出现无法安装的情况请自行对apk工具进行签名
2. 可在android/hardware/xradio/rftest-tools目录下执行 mm -j 命令生成apk，再对其进行签名