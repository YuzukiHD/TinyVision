
version：v1.2.2

- btetf version：V1.1.3
	- 增加退出ETF命令

version：v1.2.1

- btetf version：V1.1.2
	- 修复XR829和XR819s BLE无法调整功率的问题

version：v1.2.0

- btetf version：V1.1.1
	- 兼容XR829和XR819s的ble_tx命令

version：v1.1.0

- 对XR819s ble_tx命令进行升级
- 命令优化，兼容XR806版本简化式命令

version：v1.0.5

- 支持BT发送单载波功能
