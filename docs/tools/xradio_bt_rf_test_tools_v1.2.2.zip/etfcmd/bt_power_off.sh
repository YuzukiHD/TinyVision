#!/system/bin/sh

echo 0 > /sys/class/rfkill/rfkill0/state
sleep 1
