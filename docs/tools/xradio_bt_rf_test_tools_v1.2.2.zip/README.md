# BT ETF

BT ETF工具是广州芯之联科技有限公司 (Xradio Technology) 用于检测其无线芯片RF性能的工具

- 支持芯片：XR829、XR819S
- 使用说明：本工具包含CLI版本和GUI版本
	- 具体请查阅各目录下的说明
	- hciattach_xr819s适用于XR819s安卓平台
	- hciattach_xr829适用于XR829安卓平台
- 版本说明：请查看[ChangeLog.md](./ChangeLog.md)

